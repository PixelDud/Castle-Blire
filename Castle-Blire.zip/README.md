# Castle Blire
 A new game for the original Game Boy. Written in C.
 
![Title Screen](https://github.com/PixelDud/Castle-Blire/blob/main/backgrounds/title.png?raw=true)
