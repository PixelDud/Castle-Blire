#include <gb/gb.h>

#ifndef _BOOT_H
#define _BOOT_H

void bootSequence();

#endif
