
#include <gb/gb.h>

#ifndef _CASTLE_H
#define _CASTLE_H

extern const int castle[9][8][8];

#endif
