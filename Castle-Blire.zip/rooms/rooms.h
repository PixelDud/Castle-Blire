
#include <gb/gb.h>

#ifndef _ROOMS_H
#define _ROOMS_H

void roomZero();
void roomOne();
void roomTwo();
void roomThree();
void roomFour();
void roomFive();
void roomSix();
void roomSeven();
void displayRoom(int);

#endif
