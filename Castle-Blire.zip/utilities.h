#include <gb/gb.h>

#ifndef _UTILITIES_H
#define _UTILITIES_H

void delayGame(UINT8);
void fadeO(UINT8);
void fadeI(UINT8);
int getInput(void);

#endif
